
import cv2
import mediapipe as mp
import pyautogui
import time
import math
from collections import deque

MODEL = "hand_landmarker.task"

# Hand landmark connections
CONNECTIONS = [
    (0,1),(1,2),(2,3),(3,4),
    (0,5),(5,6),(6,7),(7,8),
    (5,9),(9,10),(10,11),(11,12),
    (9,13),(13,14),(14,15),(15,16),
    (13,17),(17,18),(18,19),(19,20),
    (0,17)
]

def distance(a, b):
    return math.hypot(a.x-b.x, a.y-b.y)

def classify(lm):
    # Thumb detection
    thumb = int(
        distance(lm[4], lm[17]) >
        distance(lm[3], lm[17])
    )

    # Index, middle, ring and pinky
    fingers = [
        int(lm[tip].y < lm[pip].y)
        for tip, pip in zip(
            [8,12,16,20],
            [6,10,14,18]
        )
    ]

    f = [thumb] + fingers

    if f == [1,1,1,1,1]:
        return "OPEN PALM"

    if f == [0,0,0,0,0]:
        return "FIST"

    if f == [0,1,0,0,0]:
        return "POINT"

    if f == [0,1,1,0,0]:
        return "PEACE"

    if f[0] == 1 and sum(f[1:]) == 0:
        if lm[4].y < lm[0].y:
            return "THUMBS UP"

    return f"{sum(f)} FINGERS"


def main():
    BaseOptions = mp.tasks.BaseOptions
    HandLandmarker = mp.tasks.vision.HandLandmarker
    Options = mp.tasks.vision.HandLandmarkerOptions
    RunningMode = mp.tasks.vision.RunningMode

    options = Options(
        base_options=BaseOptions(model_asset_path=MODEL),
        running_mode=RunningMode.VIDEO,
        num_hands=1,
        min_hand_detection_confidence=0.6,
        min_hand_presence_confidence=0.6,
        min_tracking_confidence=0.6
    )

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("ERROR: Webcam not found!")
        return

    history = deque(maxlen=8)
    last_action = 0
    cooldown = 1.0
    actions_enabled = False
    pyautogui.FAILSAFE = True

    actions = {
        "FIST": lambda: pyautogui.press("space"),
        "PEACE": lambda: pyautogui.press("right"),
        "POINT": lambda: pyautogui.press("left"),
        "THUMBS UP": lambda: pyautogui.press("volumeup")
    }

    print("Hand Gesture Recognition Started!")
    print("Press A to enable/disable actions.")
    print("Press Q to quit.")

    with HandLandmarker.create_from_options(options) as detector:
        while True:
            success, frame = cap.read()

            if not success:
                print("Cannot read webcam!")
                break

            frame = cv2.flip(frame, 1)
            h, w, _ = frame.shape

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

            mp_image = mp.Image(
                image_format=mp.ImageFormat.SRGB,
                data=rgb
            )

            timestamp = time.perf_counter_ns() // 1_000_000

            result = detector.detect_for_video(
                mp_image, timestamp
            )

            label = "NO HAND"

            if result.hand_landmarks:
                lm = result.hand_landmarks[0]

                # Draw hand connections
                for start, end in CONNECTIONS:
                    x1 = int(lm[start].x * w)
                    y1 = int(lm[start].y * h)
                    x2 = int(lm[end].x * w)
                    y2 = int(lm[end].y * h)

                    cv2.line(
                        frame, (x1,y1), (x2,y2),
                        (0,255,0), 2
                    )

                # Draw landmark points
                for point in lm:
                    x = int(point.x * w)
                    y = int(point.y * h)
                    cv2.circle(
                        frame, (x,y), 4,
                        (0,0,255), -1
                    )

                history.append(classify(lm))

                label = max(set(history), key=history.count)

                stable = (
                    len(history) == 8 and
                    history.count(label) >= 7
                )

                now = time.time()

                if (
                    actions_enabled and stable
                    and label in actions
                    and now - last_action > cooldown
                ):
                    actions[label]()
                    last_action = now

            else:
                history.clear()

            # Interface
            cv2.rectangle(
                frame, (0,0), (w,100),
                (20,20,20), -1
            )

            cv2.putText(
                frame, "GESTURE: " + label,
                (15,40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8, (0,255,0), 2
            )

            status = (
                "ACTIONS: ON" if actions_enabled
                else "ACTIONS: OFF"
            )

            cv2.putText(
                frame, status + " | A: TOGGLE | Q: EXIT",
                (15,75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55, (255,255,255), 1
            )

            cv2.imshow("HAND GESTURE RECOGNITION", frame)

            key = cv2.waitKey(1) & 0xFF

            if key == ord('q'):
                break

            elif key == ord('a'):
                actions_enabled = not actions_enabled
                history.clear()

    cap.release()
    cv2.destroyAllWindows()
    print("Project closed!")


if __name__ == "__main__":
    main()
